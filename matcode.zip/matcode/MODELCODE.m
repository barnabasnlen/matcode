exceldocument=input('enter the name of excel document containig data:');
[DATA,TILTE,DOCUMENT]=xlsread(exceldocument);
a=input('enter density contrast:'); 
x1=input('enter origin abscissa in km:');
y1=input('enter origin ordinate in km:');
z1=input('enter the depth in km:');
lx=input('enter the length of anomaly in km along x:');
ly=input('enter the length of anomaly in km along y:');
lz=input('enter the length of anomaly in km along z:');
px=input('enter the step in km along x:');
py=input('enter the step in km along x:');
lx1=input('enter the length of area in km along x:');
ly1=input('enter the length of area in km along x:');
head={'x';'y';'g'}';
nx=(lx1/px)+1;
ny=(ly1/py)+1;
N=nx*ny;
ms=zeros(N,2);
z2=z1+lz;
g=zeros(N,1);
k=1;
for i=0:px:lx1;
   for j=0:py:ly1; 
    ms(k,1)=i;
     ms(k,2)=j;
     k=k+1;
   end
end
for i=1:N; 
  x11=x1-ms(i,1);
  y11=y1-ms(i,2);
  z11=z1;
  x12=x11+lx;
  y12=y11+ly;
  z12=z2;
  T1=sqrt(x12^2+y12^2+z12^2);
  T2=sqrt(x12^2+y12^2+z11^2);
  T3=sqrt(x12^2+y11^2+z12^2);
  T4=sqrt(x12^2+y11^2+z11^2);
  T5=sqrt(x11^2+y12^2+z12^2);
  T6=sqrt(x11^2+y12^2+z11^2);
  T7=sqrt(x11^2+y11^2+z12^2);
  T8=sqrt(x11^2+y11^2+z11^2);
  T9=x12*(log((T1+y12)/(T1-y12))-log((T2+y12)/(T2-y12))-log((T3+y11)/(T3-y11))+log((T4+y11)/(T4-y11)));
  T10=y12*(log((T1+x12)/(T1-x12))-log((T2+x12)/(T2-x12))-log((T5+x11)/(T5-x11))+log((T6+x11)/(T6-x11)));
  T11=y11*(log((T4+x12)/(T4-x12))-log((T3+x12)/(T3-x12))-log((T8+x11)/(T8-x11))+log((T7+x11)/(T7-x11)));
  T12=x11*(log((T6+y12)/(T6-y12))-log((T5+y12)/(T5-y12))-log((T8+y11)/(T8-y11))+log((T7+y11)/(T7-y11)));
  T13=2*z12*(atan((x12*y11)/(z12*T3))-atan((x12*y12)/(z12*T1))-atan((x11*y11)/(z12*T7))+atan((x11*y12)/(z12*T5)));
  T14=2*z11*(atan((x12*y12)/(z11*T2))-atan((x12*y11)/(z11*T4))-atan((x11*y12)/(z11*T6))+atan((x11*y11)/(z11*T8)));
  g(i,1)=(3.335e-11)*1e5*a*(T9+T10+T11+T12+T13+T14);
end
xlswrite(exceldocument,head,strcat('A',int2str(1),':C',int2str(1)))
xlswrite(exceldocument,ms,strcat('A',int2str(2),':B',int2str(N+1)))
xlswrite(exceldocument,g,strcat('C',int2str(2),':C',int2str(N+1)))